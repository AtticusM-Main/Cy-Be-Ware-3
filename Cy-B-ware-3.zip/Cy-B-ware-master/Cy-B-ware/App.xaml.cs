using System.Windows;

namespace CyBware
{
    public partial class App : Application
    {
    }
}
