using System.Collections.ObjectModel;
using CyBware.Models;

namespace CyBware.Core
{
    // Task 4: stores every significant action the bot takes with a timestamp.
    public class ActivityLog
    {
        private readonly List<ActivityEntry> _entries = new();

        public ObservableCollection<ActivityEntry> Recent { get; } = new();

        public void Record(string description)
        {
            var entry = new ActivityEntry(description);
            _entries.Add(entry);
            Recent.Insert(0, entry);
        }

        public IReadOnlyList<ActivityEntry> All => _entries;

        // The brief returns the last 5-10 actions when the user asks for the log.
        public string BuildSummary(int count = 5)
        {
            if (_entries.Count == 0)
                return "I haven't done anything worth logging yet.";

            int take = Math.Min(count, _entries.Count);
            var lines = new List<string> { "Here's a summary of recent actions:" };

            int number = 1;
            for (int i = _entries.Count - take; i < _entries.Count; i++)
            {
                lines.Add($"  {number}. [{_entries[i].TimeStamp}] {_entries[i].Description}");
                number++;
            }

            return string.Join("\n", lines);
        }
    }
}
