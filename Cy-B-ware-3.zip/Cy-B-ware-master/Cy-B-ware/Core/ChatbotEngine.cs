using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using CyBware.Models;

namespace CyBware.Core
{
    // What the GUI should do after a line of input is processed.
    public enum BotAction
    {
        None,
        StartQuiz,
        ShowTasks,
        ShowLog
    }

    public class BotResult
    {
        public string Reply { get; set; } = string.Empty;
        public BotAction Action { get; set; } = BotAction.None;
    }

    // Carries the Part 1/2 chatbot (keyword responses, sentiment) and the Part 3
    // NLP routing that turns free text into tasks, reminders and commands.
    public class ChatbotEngine
    {
        private readonly Random _random = new();
        public string UserName { get; set; } = "Friend";

        public ObservableCollection<TaskItem> Tasks { get; } = new();
        public ActivityLog Log { get; } = new();

        public BotResult Process(string raw)
        {
            string input = (raw ?? string.Empty).Trim();
            if (input.Length == 0)
                return new BotResult { Reply = "I didn't catch that. Type a question or a command like 'add a task to enable 2FA'." };

            string lower = input.ToLowerInvariant();

            // Part 3 / Task 4: let the user pull up the activity log by voice.
            if (Matches(lower, "show activity log", "activity log", "what have you done", "show log", "recent actions", "show history"))
            {
                Log.Record("Displayed the activity log");
                return new BotResult { Reply = Log.BuildSummary(7), Action = BotAction.ShowLog };
            }

            // Part 3 / Task 2: start the quiz from chat.
            if (Matches(lower, "start quiz", "play quiz", "take the quiz", "quiz me", "test me", "mini game", "play the game", "start the game"))
            {
                Log.Record("Started the cybersecurity quiz");
                return new BotResult { Reply = "Starting the quiz. Switch to the Quiz tab and pick your answers.", Action = BotAction.StartQuiz };
            }

            // Part 3 / Task 1 + Task 3: reminders and tasks via natural language.
            if (LooksLikeReminder(lower))
                return AddTaskFromText(input, lower, reminderImplied: true);

            if (LooksLikeTask(lower))
                return AddTaskFromText(input, lower, reminderImplied: false);

            // Part 1/2: keyword responses, with sentiment colouring the reply.
            string answer = GetKnowledgeResponse(lower);
            string mood = DetectSentiment(lower);
            if (mood.Length > 0)
                answer = mood + "\n\n" + answer;

            return new BotResult { Reply = answer };
        }

        // ---- Task 1 + Task 3: task and reminder handling ----------------------

        public TaskItem AddTask(string title, DateTime? reminder)
        {
            var task = new TaskItem { Title = title, ReminderDate = reminder };
            Tasks.Insert(0, task);

            if (reminder.HasValue)
                Log.Record($"Task added: '{title}' (reminder {reminder.Value:dd MMM yyyy})");
            else
                Log.Record($"Task added: '{title}' (no reminder set)");

            return task;
        }

        private BotResult AddTaskFromText(string original, string lower, bool reminderImplied)
        {
            DateTime? reminder = ExtractDate(lower);
            string title = ExtractTaskTitle(original);

            if (title.Length == 0)
                return new BotResult { Reply = "Sure, what is the task? Try 'add a task to review my privacy settings'." };

            AddTask(title, reminder);

            if (reminder.HasValue)
                return new BotResult
                {
                    Reply = $"Reminder set for '{title}' on {reminder.Value:dd MMM yyyy}.",
                    Action = BotAction.ShowTasks
                };

            return new BotResult
            {
                Reply = $"Task added: '{title}'. Would you like to set a reminder for it? You can pick a date on the Tasks tab.",
                Action = BotAction.ShowTasks
            };
        }

        private static bool LooksLikeReminder(string lower) =>
            lower.Contains("remind me") || lower.Contains("set a reminder") ||
            lower.Contains("set reminder") || lower.Contains("reminder to") ||
            lower.Contains("remind me to");

        private static bool LooksLikeTask(string lower) =>
            lower.Contains("add a task") || lower.Contains("add task") ||
            lower.Contains("new task") || lower.Contains("create a task") ||
            lower.Contains("create task") || lower.Contains("set a task") ||
            lower.Contains("i need to") || lower.Contains("can you remind");

        // Pulls the task wording out of the sentence by dropping the command words.
        private static string ExtractTaskTitle(string original)
        {
            string text = original;

            string[] leadIns =
            {
                "can you remind me to", "could you remind me to", "please remind me to",
                "remind me to", "set a reminder to", "set a reminder for", "set reminder to",
                "reminder to", "add a task to", "add a task", "add task to", "add task",
                "create a task to", "create task to", "new task to", "new task",
                "set a task to", "i need to", "can you", "please"
            };

            foreach (var lead in leadIns)
            {
                int at = text.ToLowerInvariant().IndexOf(lead, StringComparison.Ordinal);
                if (at >= 0)
                {
                    text = text.Substring(at + lead.Length);
                    break;
                }
            }

            // Strip a trailing date phrase so the title reads cleanly.
            string[] dateTails = { " tomorrow", " today", " tonight", " next week", " this week" };
            foreach (var tail in dateTails)
            {
                int at = text.ToLowerInvariant().IndexOf(tail, StringComparison.Ordinal);
                if (at >= 0)
                    text = text.Substring(0, at);
            }

            text = Regex.Replace(text, @"\s+in\s+\d+\s+days?$", string.Empty, RegexOptions.IgnoreCase);
            text = text.Trim().TrimEnd('.', '!', '?').Trim();

            if (text.Length > 0)
                text = char.ToUpper(text[0]) + text.Substring(1);

            return text;
        }

        // Reads simple date phrases. Defaults reminder words to tomorrow.
        private static DateTime? ExtractDate(string lower)
        {
            if (lower.Contains("tomorrow") || lower.Contains("tonight"))
                return DateTime.Today.AddDays(1);
            if (lower.Contains("today"))
                return DateTime.Today;
            if (lower.Contains("next week"))
                return DateTime.Today.AddDays(7);
            if (lower.Contains("this week"))
                return DateTime.Today.AddDays(3);

            var match = Regex.Match(lower, @"in\s+(\d+)\s+days?");
            if (match.Success && int.TryParse(match.Groups[1].Value, out int days))
                return DateTime.Today.AddDays(days);

            if (lower.Contains("remind"))
                return DateTime.Today.AddDays(1);

            return null;
        }

        // ---- Part 1/2: sentiment detection -----------------------------------

        private string DetectSentiment(string lower)
        {
            if (Matches(lower, "worried", "scared", "nervous", "afraid", "anxious", "hacked", "stolen", "breached"))
                return $"I can tell this is stressful, {UserName}. Take a breath, you're in the right place.";
            if (Matches(lower, "confused", "don't understand", "dont understand", "lost", "no idea"))
                return $"No problem, {UserName}. Let's break it down simply.";
            if (Matches(lower, "frustrated", "annoyed", "angry", "fed up"))
                return $"I hear you, {UserName}. Let's sort this out together.";
            if (Matches(lower, "thank", "great", "awesome", "love this", "helpful"))
                return $"Glad to help, {UserName}!";
            return string.Empty;
        }

        // ---- Part 1/2: keyword knowledge base --------------------------------

        private string GetKnowledgeResponse(string input)
        {
            if (input.Contains("how are you") || input.Contains("how do you do"))
                return $"I'm running at full security protocols, {UserName}. Always alert and ready to help keep you safe online.";

            if (input.Contains("purpose") || input.Contains("what do you do") ||
                input.Contains("who are you") || input.Contains("what are you"))
                return $"I'm Cy-B-Ware, {UserName}. I teach password safety, phishing, safe browsing and more, and I can manage your cybersecurity tasks and reminders.";

            if (input.Contains("what can i ask") || input.Contains("help") ||
                input.Contains("topics") || input.Contains("what can you do"))
                return "Ask me about: passwords, phishing, safe browsing, 2FA, malware or social engineering. " +
                       "You can also say 'add a task to enable 2FA', 'remind me to update my password tomorrow', " +
                       "'start quiz', or 'show activity log'.";

            if (input.Contains("password") || input.Contains("passphrase") || input.Contains("credentials"))
            {
                var responses = new List<string>
                {
                    $"Top password tips, {UserName}:\n" +
                    "  1. Use at least 12 characters, longer is stronger.\n" +
                    "  2. Mix uppercase, lowercase, numbers and symbols.\n" +
                    "  3. Never reuse passwords across sites.\n" +
                    "  4. Use a trusted password manager.\n" +
                    "  5. Turn on two-factor authentication where you can.",

                    $"Password safety, {UserName}:\n" +
                    "  - Avoid names, birthdays and dictionary words.\n" +
                    "  - A passphrase like 'Coffee!Rain#42Mountain' is strong and memorable.\n" +
                    "  - Change a password straight away if you suspect a breach."
                };
                return responses[_random.Next(responses.Count)];
            }

            if (input.Contains("phishing") || input.Contains("phish") || input.Contains("scam") ||
                input.Contains("suspicious email") || input.Contains("fake email") || input.Contains("fraud"))
            {
                var responses = new List<string>
                {
                    $"Phishing is a top threat, {UserName}:\n" +
                    "  - Check the sender's address for misspellings.\n" +
                    "  - Be wary of urgent language like 'Act now!'.\n" +
                    "  - Hover over links to see the real URL first.\n" +
                    "  - Real organisations never ask for your password by email.",

                    $"If an email looks suspicious, {UserName}:\n" +
                    "  1. Don't click links or open attachments.\n" +
                    "  2. Report it to IT or your email provider.\n" +
                    "  3. Delete it. When in doubt, throw it out."
                };
                return responses[_random.Next(responses.Count)];
            }

            if (input.Contains("browsing") || input.Contains("browser") || input.Contains("internet") ||
                input.Contains("website") || input.Contains("https") || input.Contains("vpn") ||
                input.Contains("public wifi") || input.Contains("safe online"))
                return $"Safe browsing tips, {UserName}:\n" +
                       "  - Look for https and a padlock before entering personal info.\n" +
                       "  - Keep your browser and plugins updated.\n" +
                       "  - Use a reputable ad blocker.\n" +
                       "  - Avoid public Wi-Fi for banking; use a VPN if you must.";

            if (input.Contains("two factor") || input.Contains("2fa") || input.Contains("mfa") ||
                input.Contains("multi factor") || input.Contains("authenticator"))
                return $"Two-factor authentication is one of the best defences, {UserName}:\n" +
                       "  - It adds a second proof of identity beyond your password.\n" +
                       "  - Prefer an authenticator app over SMS codes.\n" +
                       "  - Turn it on for email, banking and social media first.";

            if (input.Contains("malware") || input.Contains("virus") || input.Contains("ransomware") ||
                input.Contains("spyware") || input.Contains("trojan") || input.Contains("antivirus"))
                return $"Malware safety, {UserName}:\n" +
                       "  - Install reputable antivirus and keep it updated.\n" +
                       "  - Only download software from official sources.\n" +
                       "  - Back up your data regularly.\n" +
                       "  - Be careful with USB drives from unknown sources.";

            if (input.Contains("social engineering") || input.Contains("pretexting") || input.Contains("vishing") ||
                input.Contains("smishing") || input.Contains("manipulation") || input.Contains("impersonat"))
                return $"Social engineering manipulates people, not machines, {UserName}:\n" +
                       "  - Attackers may pose as colleagues, banks or IT support.\n" +
                       "  - Verify identities before sharing anything sensitive.\n" +
                       "  - It's fine to hang up and call back on an official number.";

            if (input.Contains("hello") || input.Contains("hi ") || input == "hi" || input.Contains("hey") ||
                input.Contains("good morning") || input.Contains("good afternoon"))
                return $"Hello, {UserName}. Ask me anything about cybersecurity, or give me a task to manage.";

            return $"I didn't quite understand that, {UserName}. Try asking about passwords, phishing, safe browsing, " +
                   "or type 'help' for everything I can do.";
        }

        private static bool Matches(string input, params string[] keywords)
        {
            foreach (var k in keywords)
                if (input.Contains(k))
                    return true;
            return false;
        }
    }
}
