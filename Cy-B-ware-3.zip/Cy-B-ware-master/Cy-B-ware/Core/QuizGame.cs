using CyBware.Models;

namespace CyBware.Core
{
    // Task 2: cybersecurity quiz. Mix of multiple-choice and true/false questions.
    public class QuizGame
    {
        private readonly List<QuizQuestion> _questions = BuildQuestions();
        private int _index;
        private int _score;

        public bool InProgress { get; private set; }
        public int Score => _score;
        public int Total => _questions.Count;
        public int CurrentNumber => _index + 1;

        public QuizQuestion Current => _questions[_index];

        public void Start()
        {
            _index = 0;
            _score = 0;
            InProgress = true;
        }

        // Returns immediate feedback for the chosen answer, then moves on.
        public string Answer(int chosenIndex, out bool wasCorrect)
        {
            var q = Current;
            wasCorrect = q.IsCorrect(chosenIndex);
            if (wasCorrect)
                _score++;

            string verdict = wasCorrect
                ? "Correct!"
                : $"Not quite. The answer was: {q.CorrectAnswer}.";

            return $"{verdict} {q.Explanation}";
        }

        public bool MoveNext()
        {
            _index++;
            if (_index >= _questions.Count)
            {
                InProgress = false;
                return false;
            }
            return true;
        }

        public string FinalVerdict()
        {
            double ratio = (double)_score / _questions.Count;
            if (ratio >= 0.8)
                return $"Great job! You scored {_score}/{_questions.Count}. You're a cybersecurity pro.";
            if (ratio >= 0.5)
                return $"Nice effort. You scored {_score}/{_questions.Count}. A little more practice and you'll be solid.";
            return $"You scored {_score}/{_questions.Count}. Keep learning to stay safe online.";
        }

        private static List<QuizQuestion> BuildQuestions() => new()
        {
            new QuizQuestion(
                "What should you do if you receive an email asking for your password?",
                new List<string> { "Reply with your password", "Delete the email", "Report the email as phishing", "Ignore it" },
                2,
                "Reporting phishing emails helps prevent scams and warns others."),

            new QuizQuestion(
                "A strong password should be at least 12 characters long.",
                new List<string> { "True", "False" },
                0,
                "Longer passwords are far harder to crack. Aim for 12 or more characters.",
                isTrueFalse: true),

            new QuizQuestion(
                "Which of these is the safest way to store many passwords?",
                new List<string> { "A notebook on your desk", "The same password everywhere", "A reputable password manager", "A text file named passwords" },
                2,
                "A password manager encrypts your credentials and lets every account stay unique."),

            new QuizQuestion(
                "Two-factor authentication only protects email accounts.",
                new List<string> { "True", "False" },
                1,
                "2FA works on banking, social media, and most modern accounts, not just email.",
                isTrueFalse: true),

            new QuizQuestion(
                "You get a text saying you won a prize. It links to an unfamiliar site. What is this likely to be?",
                new List<string> { "A genuine reward", "Smishing (SMS phishing)", "A software update", "A bank notice" },
                1,
                "Unexpected prize links over SMS are a classic smishing attempt. Don't click."),

            new QuizQuestion(
                "It is safe to do online banking on public Wi-Fi without a VPN.",
                new List<string> { "True", "False" },
                1,
                "Public Wi-Fi can be intercepted. Use a VPN or mobile data for sensitive tasks.",
                isTrueFalse: true),

            new QuizQuestion(
                "Before entering personal details on a website, what should you check for?",
                new List<string> { "A colourful design", "https and a padlock icon", "Lots of pop-ups", "A long web address" },
                1,
                "https and the padlock show the connection is encrypted."),

            new QuizQuestion(
                "What is the best response to an urgent 'act now or your account closes' email?",
                new List<string> { "Click the link quickly", "Verify through the official website or app", "Reply with your details", "Forward it to friends" },
                1,
                "Urgency is a pressure tactic. Always verify through a channel you trust."),

            new QuizQuestion(
                "Antivirus software never needs updating once installed.",
                new List<string> { "True", "False" },
                1,
                "New threats appear daily. Keep antivirus and its definitions up to date.",
                isTrueFalse: true),

            new QuizQuestion(
                "Someone calls claiming to be IT support and asks for your password. What should you do?",
                new List<string> { "Give it to them", "Refuse and verify on an official number", "Put them on hold", "Email it instead" },
                1,
                "Real IT staff never need your password. Hang up and call back officially."),

            new QuizQuestion(
                "Ransomware can lock your files until you pay a fee.",
                new List<string> { "True", "False" },
                0,
                "Regular backups are the best defence so you never have to consider paying.",
                isTrueFalse: true),

            new QuizQuestion(
                "Which habit reduces the damage if one account is breached?",
                new List<string> { "Using one password everywhere", "Sharing passwords with friends", "Using a unique password per account", "Writing passwords on sticky notes" },
                2,
                "Unique passwords stop one breach from unlocking all your other accounts.")
        };
    }
}
