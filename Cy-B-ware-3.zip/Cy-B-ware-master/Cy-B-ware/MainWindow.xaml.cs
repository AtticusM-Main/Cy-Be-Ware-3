using System.IO;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using CyBware.Core;
using CyBware.Models;

namespace CyBware
{
    public partial class MainWindow : Window
    {
        private readonly ChatbotEngine _engine = new();
        private readonly QuizGame _quiz = new();

        public MainWindow()
        {
            InitializeComponent();

            TasksList.ItemsSource = _engine.Tasks;
            _engine.Tasks.CollectionChanged += (_, _) => UpdateTaskHint();
            _engine.Log.Recent.CollectionChanged += (_, _) => RefreshLog();

            UpdateTaskHint();
            RefreshLog();

            Loaded += OnLoaded;
        }

        private void OnLoaded(object? sender, RoutedEventArgs e)
        {
            PlayGreeting();
            AddBot($"Hello, {_engine.UserName}. I'm Cy-B-Ware, your cybersecurity assistant. " +
                   "Set your name in the top right, then ask me anything or give me a task.");
            ChatInput.Focus();
        }

        // Carried over from Part 1/2: optional spoken greeting if the file is present.
        private void PlayGreeting()
        {
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");
                if (File.Exists(path))
                    new SoundPlayer(path).Play();
            }
            catch
            {
                // A missing or unreadable audio file should not stop the app.
            }
        }

        // ---- Chat ------------------------------------------------------------

        private void Send_Click(object sender, RoutedEventArgs e) => SendInput();

        private void ChatInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                SendInput();
        }

        private void SendInput()
        {
            string text = ChatInput.Text.Trim();
            if (text.Length == 0)
                return;

            AddUser(text);
            ChatInput.Clear();

            BotResult result = _engine.Process(text);
            AddBot(result.Reply);

            switch (result.Action)
            {
                case BotAction.StartQuiz:
                    SideTabs.SelectedIndex = 1;
                    BeginQuiz();
                    break;
                case BotAction.ShowTasks:
                    SideTabs.SelectedIndex = 0;
                    break;
                case BotAction.ShowLog:
                    SideTabs.SelectedIndex = 2;
                    break;
            }
        }

        private void AddUser(string text) => AddMessage(new ChatMessage(Sender.User, text));
        private void AddBot(string text) => AddMessage(new ChatMessage(Sender.Bot, text));
        private void AddSystem(string text) => AddMessage(new ChatMessage(Sender.System, text));

        private void AddMessage(ChatMessage message)
        {
            MessagesPanel.Items.Add(message);
            MessagesScroll.ScrollToEnd();
        }

        // ---- Name ------------------------------------------------------------

        private void NameBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                CommitName();
                Keyboard.ClearFocus();
            }
        }

        private void NameBox_Commit(object sender, RoutedEventArgs e) => CommitName();

        private void CommitName()
        {
            string name = NameBox.Text.Trim();
            if (name.Length == 0)
            {
                NameBox.Text = _engine.UserName;
                return;
            }
            if (name == _engine.UserName)
                return;

            _engine.UserName = name;
            _engine.Log.Record($"User set their name to '{name}'");
            AddSystem($"Name set to {name}.");
        }

        // ---- Task 1: Task assistant -----------------------------------------

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            string title = TaskTitleBox.Text.Trim();
            if (title.Length == 0)
            {
                AddSystem("Enter a task name before adding.");
                return;
            }

            DateTime? reminder = ReminderPicker.SelectedDate;
            _engine.AddTask(title, reminder);

            TaskTitleBox.Clear();
            ReminderPicker.SelectedDate = null;

            AddBot(reminder.HasValue
                ? $"Task added: '{title}'. Reminder set for {reminder.Value:dd MMM yyyy}."
                : $"Task added: '{title}'. No reminder set.");
        }

        private void CompleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button { Tag: TaskItem task })
            {
                task.IsComplete = true;
                _engine.Log.Record($"Task marked complete: '{task.Title}'");
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button { Tag: TaskItem task })
            {
                _engine.Tasks.Remove(task);
                _engine.Log.Record($"Task deleted: '{task.Title}'");
            }
        }

        private void UpdateTaskHint() =>
            NoTasksHint.Visibility = _engine.Tasks.Count == 0 ? Visibility.Visible : Visibility.Collapsed;

        // ---- Task 2: Quiz ----------------------------------------------------

        private void StartQuiz_Click(object sender, RoutedEventArgs e) => BeginQuiz();

        private void BeginQuiz()
        {
            _quiz.Start();
            _engine.Log.Record("Quiz started");
            QuizStartPanel.Visibility = Visibility.Collapsed;
            QuizPlayPanel.Visibility = Visibility.Visible;
            QuizScoreText.Text = string.Empty;
            ShowQuestion();
        }

        private void ShowQuestion()
        {
            QuizQuestion q = _quiz.Current;
            QuizProgressText.Text = $"Question {_quiz.CurrentNumber} of {_quiz.Total}   |   Score {_quiz.Score}";
            QuizPromptText.Text = q.Prompt;

            QuizOptionsPanel.Children.Clear();
            for (int i = 0; i < q.Options.Count; i++)
            {
                var btn = new Button
                {
                    Content = new TextBlock { Text = q.Options[i], TextWrapping = TextWrapping.Wrap },
                    Tag = i,
                    Style = (Style)FindResource("GhostButton"),
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    HorizontalContentAlignment = HorizontalAlignment.Left,
                    Margin = new Thickness(0, 0, 0, 8)
                };
                btn.Click += QuizOption_Click;
                QuizOptionsPanel.Children.Add(btn);
            }

            QuizFeedback.Visibility = Visibility.Collapsed;
            QuizNextButton.Visibility = Visibility.Collapsed;
        }

        private void QuizOption_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button { Tag: int chosen })
                return;

            foreach (Button b in QuizOptionsPanel.Children.OfType<Button>())
                b.IsEnabled = false;

            string feedback = _quiz.Answer(chosen, out _);
            QuizFeedbackText.Text = feedback;
            QuizFeedback.Visibility = Visibility.Visible;

            QuizNextButton.Content = _quiz.CurrentNumber >= _quiz.Total ? "See Result" : "Next";
            QuizNextButton.Visibility = Visibility.Visible;
        }

        private void QuizNext_Click(object sender, RoutedEventArgs e)
        {
            if (_quiz.MoveNext())
            {
                ShowQuestion();
            }
            else
            {
                EndQuiz();
            }
        }

        private void EndQuiz()
        {
            string verdict = _quiz.FinalVerdict();
            QuizPlayPanel.Visibility = Visibility.Collapsed;
            QuizStartPanel.Visibility = Visibility.Visible;

            _engine.Log.Record($"Quiz completed - scored {_quiz.Score}/{_quiz.Total}");
            AddBot(verdict);
        }

        // ---- Task 4: Activity log -------------------------------------------

        private void HistoryToggle_Changed(object sender, RoutedEventArgs e) => RefreshLog();

        private void RefreshLog()
        {
            if (LogList == null)
                return;

            bool full = ShowFullHistory.IsChecked == true;
            var source = full
                ? _engine.Log.Recent.ToList()
                : _engine.Log.Recent.Take(10).ToList();

            LogList.ItemsSource = source;
            NoLogHint.Visibility = source.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }
    }
}
