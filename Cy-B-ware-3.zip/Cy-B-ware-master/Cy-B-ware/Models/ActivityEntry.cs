namespace CyBware.Models
{
    public class ActivityEntry
    {
        public DateTime Time { get; }
        public string Description { get; }

        public ActivityEntry(string description)
        {
            Time = DateTime.Now;
            Description = description;
        }

        public string TimeStamp => Time.ToString("dd MMM HH:mm");
    }
}
