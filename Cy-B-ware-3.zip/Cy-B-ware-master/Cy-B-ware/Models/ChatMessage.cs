namespace CyBware.Models
{
    public enum Sender
    {
        Bot,
        User,
        System
    }

    public class ChatMessage
    {
        public Sender Sender { get; }
        public string Text { get; }
        public string Time { get; }

        public ChatMessage(Sender sender, string text)
        {
            Sender = sender;
            Text = text;
            Time = DateTime.Now.ToString("HH:mm");
        }

        public bool IsUser => Sender == Sender.User;
        public bool IsBot => Sender == Sender.Bot;
        public bool IsSystem => Sender == Sender.System;

        public string Label => Sender switch
        {
            Sender.User => "You",
            Sender.Bot => "Cy-B-Ware",
            _ => "System"
        };
    }
}
