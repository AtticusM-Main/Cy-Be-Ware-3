namespace CyBware.Models
{
    public class QuizQuestion
    {
        public string Prompt { get; }
        public List<string> Options { get; }
        public int CorrectIndex { get; }
        public string Explanation { get; }
        public bool IsTrueFalse { get; }

        public QuizQuestion(string prompt, List<string> options, int correctIndex, string explanation, bool isTrueFalse = false)
        {
            Prompt = prompt;
            Options = options;
            CorrectIndex = correctIndex;
            Explanation = explanation;
            IsTrueFalse = isTrueFalse;
        }

        public bool IsCorrect(int chosenIndex) => chosenIndex == CorrectIndex;

        public string CorrectAnswer => Options[CorrectIndex];
    }
}
