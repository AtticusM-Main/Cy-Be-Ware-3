using System.ComponentModel;

namespace CyBware.Models
{
    public class TaskItem : INotifyPropertyChanged
    {
        private string _title = string.Empty;
        private bool _isComplete;
        private DateTime? _reminderDate;

        public string Title
        {
            get => _title;
            set { _title = value; OnChanged(nameof(Title)); }
        }

        public bool IsComplete
        {
            get => _isComplete;
            set { _isComplete = value; OnChanged(nameof(IsComplete)); OnChanged(nameof(StatusText)); }
        }

        public DateTime? ReminderDate
        {
            get => _reminderDate;
            set { _reminderDate = value; OnChanged(nameof(ReminderDate)); OnChanged(nameof(ReminderText)); OnChanged(nameof(HasReminder)); }
        }

        public DateTime Created { get; } = DateTime.Now;

        public bool HasReminder => _reminderDate.HasValue;

        public string ReminderText => _reminderDate.HasValue
            ? "Reminder: " + _reminderDate.Value.ToString("dd MMM yyyy")
            : "No reminder set";

        public string StatusText => _isComplete ? "Done" : "Pending";

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
